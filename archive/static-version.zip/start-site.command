#!/bin/bash
# Double-click this file to view the website in your browser.
# It starts a small local web server in this folder and opens the home page.
cd "$(dirname "$0")" || exit 1
PORT=8765
if ! lsof -iTCP:$PORT -sTCP:LISTEN >/dev/null 2>&1; then
  python3 -m http.server $PORT --bind 127.0.0.1 >/dev/null 2>&1 &
  sleep 1
fi
open "http://127.0.0.1:$PORT/"
echo "The website is running at http://127.0.0.1:$PORT/ — close this window to stop it."
wait
