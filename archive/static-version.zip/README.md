# Our Lady of the Most Holy Trinity Chapel — website

A static recreation of https://olmhtchurch.org (the live site is built with GoDaddy Website Builder).
Every page is a plain HTML file, so the whole site can be edited with a text editor and
viewed in any browser. No build step and no database.

## Open the site

- Double-click `start-site.command`. It starts a small local web server in this folder and
  opens the home page in your browser. Close its Terminal window to stop the server.
- Or open `index.html` directly in a browser.

## Pages

| File | Page |
| --- | --- |
| `index.html` | Home: Mass schedule, notices, sermons, videos, PDF viewer |
| `about.html` | About Us |
| `contact-us.html` | Contact Us |
| `donation.html` | Donation |
| `dress-code.html` | Traditional Catholic Dress Code |
| `submission-to-magisterium.html` | Submission to the Catholic Magisterium |
| `profession-of-faith.html`, `athanasian-creed.html` | Catholic Creeds |
| `penny-catechism-pdf.html`, `catecismo-mons-carmona.html` | Catechisms |
| `cum-ex-apostolatus.html`, `unam-sanctam.html` | Papal Documents |
| `our-ladys-fatima-message.html`, `sun-miracle-10-13.html`, `pope-urban-viii-galileo.html` | Our Lady of Fatima |
| `declaration-bishop-thuc.html` | Bishop Thuc |
| `examination-of-conscience.html` | Resources |

## Folders

- `assets/css/style.css` — all styling. Colors and fonts are defined as variables at the top of the file.
- `assets/js/main.js` — the slide-in menu and the contact form behavior.
- `assets/img/` — photos and PDF preview images. `assets/pdf/` — the downloadable documents.
- `assets/fonts/` — the three web fonts (Vollkorn, Archivo Black, Montserrat), served locally.

## Making changes

- The Mass schedule and weekly notices are in `index.html`. Search for
  `TRADITIONAL LATIN MASS SCHEDULE` to find them.
- The menu is repeated in every page (the `<nav class="drawer">` block near the end of each
  file), so a menu change needs to be made in all 17 files.
- The contact form shows a confirmation message but does not send email yet. To send real
  email, connect it to a form service (for example Formspree or Netlify Forms) by setting the
  form's `action` attribute.
- Videos are YouTube embeds. To change one, replace the video ID in the `iframe` `src`.
